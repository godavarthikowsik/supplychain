from flask import Flask, jsonify, render_template, request
from web3 import Web3

app = Flask(__name__)

ganache_url = "http://127.0.0.1:7545"
web3 = Web3(Web3.HTTPProvider(ganache_url))
web3.eth.default_account = web3.eth.accounts[0]

contract_address = "0x939873b714c8C54630eE966c7370baB38eDdd9bc"
contract_abi = [
	{
		"anonymous": False,
		"inputs": [
			{
				"indexed": False,
				"internalType": "uint256",
				"name": "productId",
				"type": "uint256"
			},
			{
				"indexed": False,
				"internalType": "address",
				"name": "from",
				"type": "address"
			},
			{
				"indexed": False,
				"internalType": "address",
				"name": "to",
				"type": "address"
			}
		],
		"name": "OwnershipTransferred",
		"type": "event"
	},
	{
		"anonymous": False,
		"inputs": [
			{
				"indexed": False,
				"internalType": "uint256",
				"name": "productId",
				"type": "uint256"
			}
		],
		"name": "ProductDelivered",
		"type": "event"
	},
	{
		"anonymous": False,
		"inputs": [
			{
				"indexed": False,
				"internalType": "uint256",
				"name": "productId",
				"type": "uint256"
			},
			{
				"indexed": False,
				"internalType": "string",
				"name": "name",
				"type": "string"
			},
			{
				"indexed": False,
				"internalType": "string",
				"name": "manufacturer",
				"type": "string"
			}
		],
		"name": "ProductRegistered",
		"type": "event"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_productId",
				"type": "uint256"
			}
		],
		"name": "markAsDelivered",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "_name",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_manufacturer",
				"type": "string"
			}
		],
		"name": "registerProduct",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_productId",
				"type": "uint256"
			},
			{
				"internalType": "address",
				"name": "_newOwner",
				"type": "address"
			}
		],
		"name": "transferOwnership",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_productId",
				"type": "uint256"
			}
		],
		"name": "getOwnershipHistory",
		"outputs": [
			{
				"internalType": "address[]",
				"name": "",
				"type": "address[]"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_productId",
				"type": "uint256"
			}
		],
		"name": "getProduct",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "id",
				"type": "uint256"
			},
			{
				"internalType": "string",
				"name": "name",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "manufacturer",
				"type": "string"
			},
			{
				"internalType": "address",
				"name": "currentOwner",
				"type": "address"
			},
			{
				"internalType": "uint256",
				"name": "timestamp",
				"type": "uint256"
			},
			{
				"internalType": "bool",
				"name": "isDelivered",
				"type": "bool"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "getProductCounter",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	}
]

contract = web3.eth.contract(address=contract_address, abi=contract_abi)


@app.route('/')
def index():
    return render_template('connect.html')

@app.route('/welcome')
def welcome():
  return render_template('index.html')


@app.route('/register', methods=['GET', 'POST'])
def register_product():
    if request.method == 'POST':
        name = request.form['name']
        manufacturer = request.form['manufacturer']
        try:
            tx_hash = contract.functions.registerProduct(name, manufacturer).transact({
                'from': web3.eth.default_account
            })
            web3.eth.wait_for_transaction_receipt(tx_hash)
            # Return success message as JSON
            return jsonify({
                'status': 'success',
                'name': name,
                'manufacturer': manufacturer
            })
        except Exception as e:
            # Return error message as JSON
            return jsonify({
                'status': 'error',
                'error': str(e)
            })

    return render_template('register.html')

@app.route('/transfer', methods=['GET', 'POST'])
def transfer_ownership():
    if request.method == 'POST':
        product_id = int(request.form['product_id'])
        new_owner = request.form['new_owner']
        try:
            # Call the contract function to transfer ownership
            tx_hash = contract.functions.transferOwnership(product_id, new_owner).transact({
                'from': web3.eth.default_account
            })
            # Wait for the transaction to be mined
            web3.eth.wait_for_transaction_receipt(tx_hash)
            return jsonify({
                'status': 'success',
                'product_id': product_id,
                'new_owner': new_owner
            })
        except Exception as e:
            return jsonify({
                'status': 'error',
                'error': str(e)
            })

    return render_template('transfer.html')



@app.route('/deliver', methods=['GET', 'POST'])
def mark_as_delivered():
    if request.method == 'POST':
        product_id = int(request.form['product_id'])
        try:
            # Interacting with the Ethereum contract to mark the product as delivered
            tx_hash = contract.functions.markAsDelivered(product_id).transact({
                'from': web3.eth.default_account
            })
            web3.eth.wait_for_transaction_receipt(tx_hash)
            # Return success response as JSON
            return jsonify({
                'status': 'success',
                'product_id': product_id
            })
        except Exception as e:
            # Return error response as JSON
            return jsonify({
                'status': 'error',
                'error': str(e)
            })

    return render_template('deliver.html')


@app.route('/product', methods=['GET', 'POST'])
def get_product_details():
    if request.method == 'POST':
        product_id = int(request.form['product_id'])
        try:
            # Fetch product details from the smart contract
            product_details = contract.functions.getProduct(product_id).call()

            # Fetch the delivery status from the smart contract
            is_delivered = product_details[5]  # isDelivered is the 6th item in the returned tuple

            # Format the delivery status as a human-readable string
            delivery_status = 'Delivered' if is_delivered else 'Not Delivered'

            # Return the details including the delivery status
            return jsonify({
                'status': 'success',
                'product_id': product_id,
                'name': product_details[1],
                'manufacturer': product_details[2],
                'currentOwner': product_details[3],
                'timestamp': product_details[4],
                'delivery_status': delivery_status
            })
        except Exception as e:
            return jsonify({
                'status': 'error',
                'error': str(e)
            })

    # To show all registered products
    try:
        products_list = []
        
        # Fetch the total number of products using the new public getter
        product_count = contract.functions.getProductCounter().call()

        # Fetch details of each product
        for product_id in range(1, product_count + 1):
            product_details = contract.functions.getProduct(product_id).call()
            is_delivered = product_details[5]  # isDelivered field
            delivery_status = 'Delivered' if is_delivered else 'Not Delivered'
            
            products_list.append({
                'product_id': product_id,
                'name': product_details[1],
                'manufacturer': product_details[2],
                'currentOwner': product_details[3],
                'timestamp': product_details[4],
                'delivery_status': delivery_status
            })
        
        return render_template('product.html', products=products_list)

    except Exception as e:
        return jsonify({
            'status': 'error',
            'error': str(e)
        })

@app.route('/history', methods=['GET', 'POST'])
def get_ownership_history():
    if request.method == 'POST':
        product_id = int(request.form['product_id'])
        try:
            # Call the contract method to get ownership history
            history = contract.functions.getOwnershipHistory(product_id).call()
            # Return the ownership history as JSON
            return jsonify({
                'status': 'success',
                'history': history
            })
        except Exception as e:
            # Return error message as JSON
            return jsonify({
                'status': 'error',
                'error': str(e)
            })

    return render_template('history.html')

if __name__ == '__main__':
    app.run(debug=True)
